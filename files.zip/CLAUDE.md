# CLAUDE.md — Rebranding: DevTasks → DevTasks-11

Fases 0, 1, 2 e 3 já estão validadas e funcionando. Esta é uma tarefa pontual de rebranding, não uma nova fase de features — não implemente nada de Fase 4 aqui.

## 🎯 Objetivo
Renomear o app de "DevTasks" para "**DevTasks-11**" em todos os pontos visíveis (código, config e docs), sem quebrar nada que já funciona.

## Regras gerais
1. Faça uma busca global por "DevTasks" e "devtasks" no projeto inteiro antes de começar, para mapear todos os lugares — não confie só na lista abaixo, ela é um guia, não uma lista exaustiva.
2. Não altere nomes de variáveis, funções ou tipos internos do código (ex: `tasksStore`, `Task`, `TaskCard`) — isso é branding visual/textual, não refactor de arquitetura.
3. Um commit só para essa tarefa: `chore: rebranding para DevTasks-11`.
4. Rode `npm run build` no final para confirmar que nada quebrou.

## 🧱 Onde alterar

- [ ] `package.json` — campo `"name"` (usar `devtasks-11`, em minúsculo e com hífen, padrão de pacotes npm)
- [ ] `index.html` — tag `<title>`
- [ ] Componente do logo/header (`Sidebar.tsx` ou onde estiver o nome do app na UI) — trocar texto visível para "DevTasks-11"
- [ ] Favicon/ícone (se houver texto ou identidade visual com o nome antigo — se for só um ícone genérico, pode deixar como está por ora)
- [ ] `README.md`, `ROADMAP.md`, `DESIGN.md` — já vêm atualizados por mim, se o agent notar alguma referência antiga que eu tenha deixado passar, corrija também
- [ ] Chave de localStorage do tema/dados, se o nome do app estiver embutido nela (ex: `devtasks-theme` → decida entre manter por compatibilidade ou migrar para `devtasks-11-theme`; se migrar, faça um fallback que lê a chave antiga na primeira execução para não perder dados dos usuários que já testaram o app)
- [ ] Nome do repositório Git remoto (isso é manual, no GitHub/GitLab — não precisa ser feito pelo agent, é só um lembrete pra você)

## ✅ Definição de pronto
- Nome "DevTasks-11" aparece corretamente na aba do navegador e na UI (header/sidebar).
- `package.json` reflete o novo nome.
- Nenhum dado do usuário (tarefas, categorias, tema) foi perdido por causa da migração de chave do localStorage.
- Build passa sem erros.
- Nenhuma feature nova foi implementada nesta tarefa — só rebranding.
